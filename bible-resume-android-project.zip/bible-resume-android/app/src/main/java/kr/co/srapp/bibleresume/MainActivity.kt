package kr.co.srapp.bibleresume

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(rememberBibleScript, null)
            }
        }
        setContentView(webView)
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl("https://srapp.vercel.app/")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private val rememberBibleScript = """
        (function() {
          if (window.__bibleResumeInstalled) return;
          window.__bibleResumeInstalled = true;
          var key = 'srapp.lastBiblePath.v1';
          function isBiblePath(path) { return /^\/bible\/\d+\/\d+/.test(path || ''); }
          function saveCurrent() {
            try {
              if (isBiblePath(location.pathname)) {
                localStorage.setItem(key, location.pathname + location.search + location.hash);
              }
            } catch (e) {}
          }
          function lastPath() {
            try {
              var p = localStorage.getItem(key);
              return isBiblePath(p) ? p : null;
            } catch (e) { return null; }
          }
          var originalPush = history.pushState;
          history.pushState = function() {
            var result = originalPush.apply(this, arguments);
            saveCurrent();
            return result;
          };
          var originalReplace = history.replaceState;
          history.replaceState = function() {
            var result = originalReplace.apply(this, arguments);
            saveCurrent();
            return result;
          };
          window.addEventListener('popstate', saveCurrent);
          saveCurrent();

          document.addEventListener('click', function(event) {
            var node = event.target;
            if (node && node.nodeType === 3) node = node.parentElement;
            var control = node && node.closest ? node.closest('a,button,[role="tab"],[role="button"]') : null;
            if (!control) return;
            var label = (control.innerText || control.getAttribute('aria-label') || control.textContent || '').replace(/\s+/g, '').trim();
            if (label.indexOf('성경') === -1 || isBiblePath(location.pathname)) return;
            var saved = lastPath();
            if (!saved) return;
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            location.href = location.origin + saved;
          }, true);

          var previous = location.pathname + location.search;
          setInterval(function() {
            var current = location.pathname + location.search;
            if (current !== previous) {
              previous = current;
              saveCurrent();
            }
          }, 350);
        })();
    """.trimIndent()
}
